#iIMPORTS
from socket import *
import time
import pandas as pd
import numpy as np

#Connection 
#bind = '10.0.2.15'
bind = ''
port = 1024
server_socket = socket(AF_INET, SOCK_DGRAM)
server_socket.bind((bind, port))

#store ans
ans = []

for i in range(100):    #as we have to transmit 100 packets
    msg, add = server_socket.recvfrom(2048)

    recv_time = int.from_bytes(msg, byteorder='little')   #I am using bydefault little endian 

    latency = ((time.time_ns()- recv_time)/1000000)
    print(latency)

    num = []                 
    #num.append(i)
    num.append(latency)
    ans.append(num)

    server_socket.sendto(msg, add)

df = pd.DataFrame(ans)
df.to_csv('wired.csv') 

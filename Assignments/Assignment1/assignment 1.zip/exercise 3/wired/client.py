#IMPORTS
import time
import sys
import socket

#connection
#host = "192.168.61.191" #I have used here loopback address for running on the same machine
#host = ""
host = "192.168.1.3"
port = 1024

timeout = 2
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_socket.settimeout(timeout)
msg = bytearray([1] * 256)

mini = 999999
maxi = 0
count = 0
received = 0
avg = 0
sleept = 1

for i in range(100):
    t = time.time_ns()        # time in nanosecond
    #print(t)
    barray = t.to_bytes(256, "little")  #little endian

    client_socket.sendto(barray, (host, port))
    start = time.time()
    data, server = client_socket.recvfrom(2048)
    end = time.time()
    diff = (end - start) * 1000
    if diff < mini: 
        mini = diff
    if diff > maxi: 
        maxi = diff
    count = count + 1
    received += 1
    avg += diff
    delay = diff - mini
    #print('received %s bytes from %s sequence=%d time=%0.1f ms delay=%0.2f ms' % (len(data), host, i, diff, delay))
    time.sleep(sleept)



#import these libraries for the functionalities
import time #for time
import sys #for system resources
import socket #for socket opening and closing.

#connection creating.

host = "192.168.1.3"
port = 1024
delays = 3 #this is the way we are setting the timeout
cs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
cs.settimeout(delays)
msg_256 = bytearray([1]*256)
count=0
minimum_timeout = 99999
maximum_timeout = 0
rcvd_packets = 0
average = 0
sleptpackets = 1

for i in range(100):
    t = time.time_ns()
    B = t.to_bytes(256, "little")  #formatting using little endian
    cs.sendto(B,(host, port))
    strt = time.time()
    data,server = cs.recvfrom(2048)
    ending = time.time()
    delta = (ending-strt+1) * 1000
    if delta < minimum_timeout: 
        minimum_timeout = delta
    if delta > maximum_timeout: 
        maximum_timeout = delta
    rcvd_packets+= 1
    count=count+1
    average += delta
    delays = delta - minimum_timeout
    #print('received %s bytes from %s sequence=%d time=%0.1f ms delay=%0.2f ms' % (len(data), host, i, diff, delay))
    time.sleep(sleptpackets)



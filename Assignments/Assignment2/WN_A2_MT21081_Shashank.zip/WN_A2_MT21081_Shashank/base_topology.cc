//include the files
#include <fstream>
#include "ns3/core-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/mobility-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/ssid.h"

//groups all ns-3-related declarations in a scope outside the global namespace
using namespace ns3;

//enable and disable console message logging by reference to the name
NS_LOG_COMPONENT_DEFINE ("Base Simulation");

//class
class MyApp : public Application{
public:
  //constructor
  MyApp ();
  //destructor
  virtual ~MyApp ();

  void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

private:
  //function declarations
  virtual void StartApplication (void);
  virtual void StopApplication (void);

  void ScheduleTx (void);
  void SendPacket (void);

  //variables
  Ptr<Socket>     m_socket;
  Address         m_peer;
  uint32_t        m_packetSize;
  uint32_t        m_nPackets;
  DataRate        m_dataRate;
  EventId         m_sendEvent;
  bool            m_running;
  uint32_t        m_packetsSent;
};

//initialization of variables
MyApp::MyApp ()
  : m_socket (0),
    m_peer (),
    m_packetSize (0),
    m_nPackets (0),
    m_dataRate (0),
    m_sendEvent (),
    m_running (false),
    m_packetsSent (0)
{
}

//free socket
MyApp::~MyApp ()
{
  m_socket = 0;
}

//setup connections
void
MyApp::Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate)
{
  m_socket = socket;
  m_peer = address;
  m_packetSize = packetSize;
  m_nPackets = nPackets;
  m_dataRate = dataRate;
}

//start applications
void
MyApp::StartApplication (void)
{
  m_running = true;
  m_packetsSent = 0;
  //bind program with socket
  m_socket->Bind ();
  //connection established
  m_socket->Connect (m_peer);
  //start sending data
  SendPacket ();
}

//stop applications
void
MyApp::StopApplication (void)
{
  m_running = false;

  if (m_sendEvent.IsRunning ())
    {
      Simulator::Cancel (m_sendEvent);
    }
  //terminate connection/ release port
  if (m_socket)
    {
      m_socket->Close ();
    }
}

//sending data
void
MyApp::SendPacket (void)
{
  //create packet with specific packetsize
  Ptr<Packet> packet = Create<Packet> (m_packetSize);
  m_socket->Send (packet);
  
  if (++m_packetsSent < m_nPackets)
    {
      ScheduleTx ();
    }
}

//Schedule tasks via simulation
void
MyApp::ScheduleTx (void)
{
  if (m_running)
    {
      Time tNext (Seconds (m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate ())));
      m_sendEvent = Simulator::Schedule (tNext, &MyApp::SendPacket, this);
    }
}

//congestion window change
static void
CwndChange (Ptr<OutputStreamWrapper> stream, uint32_t oldCwnd, uint32_t newCwnd)
{
//   NS_LOG_UNCOND (Simulator::Now ().GetSeconds () << "\t" << newCwnd);
   *stream->GetStream () << Simulator::Now ().GetSeconds () << "\t" << oldCwnd << "\t" << newCwnd << std::endl;
}

// Base Network Topology (ISP->PC1)
//
//   Wifi 10.1.3.0
//                         AP
// *   *    *    *    *    *
// |    |   |    |    |    |            10.1.1.0
// n5  n4  n3   n2   n1   n0(router) -------------- ISP 
//                         |         point-to-point  
//                      PC1(csma)             
//                         |                
//                      PC2(csma)


int 
main (int argc, char *argv[])
{
  bool verbose = true;
  uint32_t nCsma = 2;
  uint32_t nWifi = 5;
  bool tracing = false;
  double error_rate = 0.000001;
  int simulation_time = 10; //seconds

  CommandLine cmd (__FILE__);
  cmd.AddValue ("nCsma", "Number of \"extra\" CSMA nodes/devices", nCsma);
  cmd.AddValue ("nWifi", "Number of wifi STA devices", nWifi);
  cmd.AddValue ("verbose", "Tell echo applications to log if true", verbose);
  cmd.AddValue ("tracing", "Enable pcap tracing", tracing);

  cmd.Parse (argc,argv);

  // The underlying restriction of 18 is due to the grid position
  // allocator's configuration; the grid layout will exceed the
  // bounding box if more than 18 nodes are provided.
  if (nWifi > 18)
    {
      std::cout << "nWifi should be 18 or less; otherwise grid layout exceeds the bounding box" << std::endl;
      return 1;
    }

  if (verbose)
    {
      LogComponentEnable ("UdpEchoClientApplication", LOG_LEVEL_INFO);
      LogComponentEnable ("UdpEchoServerApplication", LOG_LEVEL_INFO);
    }

  NodeContainer p2pNodes;
  p2pNodes.Create (2);

  PointToPointHelper pointToPoint;
  pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("5Mbps"));
  pointToPoint.SetChannelAttribute ("Delay", StringValue ("2ms"));

  NetDeviceContainer p2pDevices;
  p2pDevices = pointToPoint.Install (p2pNodes);

  NodeContainer csmaNodes;
  csmaNodes.Add (p2pNodes.Get (0));
  csmaNodes.Create (nCsma);

  CsmaHelper csma;
  csma.SetChannelAttribute ("DataRate", StringValue ("100Mbps"));
  csma.SetChannelAttribute ("Delay", TimeValue (NanoSeconds (6560)));

  NetDeviceContainer csmaDevices;
  csmaDevices = csma.Install (csmaNodes);

  NodeContainer wifiStaNodes;
  wifiStaNodes.Create (nWifi);
  NodeContainer wifiApNode = p2pNodes.Get (0);

  YansWifiChannelHelper channel = YansWifiChannelHelper::Default ();
  YansWifiPhyHelper phy;
  phy.SetChannel (channel.Create ());

  WifiHelper wifi;
  wifi.SetRemoteStationManager ("ns3::AarfWifiManager");

  WifiMacHelper mac;
  Ssid ssid = Ssid ("ns-3-ssid");
  mac.SetType ("ns3::StaWifiMac",
               "Ssid", SsidValue (ssid),
               "ActiveProbing", BooleanValue (false));

  NetDeviceContainer staDevices;
  staDevices = wifi.Install (phy, mac, wifiStaNodes);

  mac.SetType ("ns3::ApWifiMac",
               "Ssid", SsidValue (ssid));

  NetDeviceContainer apDevices;
  apDevices = wifi.Install (phy, mac, wifiApNode);

  MobilityHelper mobility;

  mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
                                 "MinX", DoubleValue (0.0),
                                 "MinY", DoubleValue (0.0),
                                 "DeltaX", DoubleValue (5.0),
                                 "DeltaY", DoubleValue (10.0),
                                 "GridWidth", UintegerValue (3),
                                 "LayoutType", StringValue ("RowFirst"));

  mobility.SetMobilityModel ("ns3::RandomWalk2dMobilityModel",
                             "Bounds", RectangleValue (Rectangle (-50, 50, -50, 50)));
  mobility.Install (wifiStaNodes);

  mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
  mobility.Install (wifiApNode);

  InternetStackHelper stack;
  stack.Install (csmaNodes);
  stack.Install (p2pNodes.Get(1));
  //stack.Install (wifiApNode);
  stack.Install (wifiStaNodes);

  Ipv4AddressHelper address;

  address.SetBase ("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer p2pInterfaces;
  p2pInterfaces = address.Assign (p2pDevices);

  address.SetBase ("10.1.2.0", "255.255.255.0");
  Ipv4InterfaceContainer csmaInterfaces;
  csmaInterfaces = address.Assign (csmaDevices);

  address.SetBase ("10.1.3.0", "255.255.255.0");
  address.Assign (staDevices);
  address.Assign (apDevices);

  
  
  
  //tcp-example.cc
  
  Ptr<RateErrorModel> em = CreateObject<RateErrorModel> ();
  em->SetAttribute ("ErrorRate", DoubleValue (error_rate));
  p2pDevices.Get (1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));
  
  uint16_t sinkPort = 8080;
  Address sinkAddress (InetSocketAddress (p2pInterfaces.GetAddress (1), sinkPort));
  PacketSinkHelper packetSinkHelper ("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), sinkPort));
  ApplicationContainer sinkApps = packetSinkHelper.Install (p2pNodes.Get (1));
  sinkApps.Start (Seconds (0.));
  sinkApps.Stop (Seconds (simulation_time));

  Ptr<Socket> ns3TcpSocket = Socket::CreateSocket (p2pNodes.Get (0), TcpSocketFactory::GetTypeId ());

  Ptr<MyApp> app = CreateObject<MyApp> ();
  app->Setup (ns3TcpSocket, sinkAddress, 1460, 1000000, DataRate ("100Mbps"));
  p2pNodes.Get (0)->AddApplication (app);
  app->SetStartTime (Seconds (1.));
  app->SetStopTime (Seconds (simulation_time));
  //tcp-example.cc
  
//   UdpEchoServerHelper echoServer (9);

//   ApplicationContainer serverApps = echoServer.Install (p2pNodes.Get (0));
//   serverApps.Start (Seconds (1.0));
//   serverApps.Stop (Seconds (10.0));

//   UdpEchoClientHelper echoClient (csmaInterfaces.GetAddress (nCsma), 9);
//   echoClient.SetAttribute ("MaxPackets", UintegerValue (1));
//   echoClient.SetAttribute ("Interval", TimeValue (Seconds (1.0)));
//   echoClient.SetAttribute ("PacketSize", UintegerValue (1024));

//   ApplicationContainer clientApps = 
//     echoClient.Install (wifiStaNodes.Get (nWifi - 1));
//   clientApps.Start (Seconds (2.0));
//   clientApps.Stop (Seconds (10.0));
  
//   UdpEchoServerHelper echoServer (9);
// 
//   ApplicationContainer serverApps = echoServer.Install (p2pNodes.Get (1));
//   serverApps.Start (Seconds (1.0));
//   serverApps.Stop (Seconds (10.0));
// 
//   UdpEchoClientHelper echoClient (p2pInterfaces.GetAddress (1), 9);
//   echoClient.SetAttribute ("MaxPackets", UintegerValue (1));
//   echoClient.SetAttribute ("Interval", TimeValue (Seconds (1.0)));
//   echoClient.SetAttribute ("PacketSize", UintegerValue (1024));
// 
//   ApplicationContainer clientApps = echoClient.Install (wifiStaNodes.Get (nWifi - 1));
//   clientApps.Start (Seconds (2.0));
//   clientApps.Stop (Seconds (10.0));
// 
//   Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

//   Simulator::Stop (Seconds (10.0));

  if (tracing == true)
    {
      pointToPoint.EnablePcapAll ("third");
      phy.EnablePcap ("third", apDevices.Get (0));
//       p2p.EnablePcap ("third", p2pDevices.Get (0), true);
    }

  //trace cwnd
  AsciiTraceHelper asciiTraceHelper;
  Ptr<OutputStreamWrapper> stream = asciiTraceHelper.CreateFileStream ("tcp-example.cwnd");
  ns3TcpSocket->TraceConnectWithoutContext ("CongestionWindow", MakeBoundCallback (&CwndChange, stream));

  //detailed trace of queue enq/deq packet tx/rx
  AsciiTraceHelper ascii;
  pointToPoint.EnableAsciiAll (ascii.CreateFileStream ("tcp-example.tr"));
  pointToPoint.EnablePcapAll ("tcp-example");

  Simulator::Stop (Seconds (simulation_time));  
  Simulator::Run ();
  Simulator::Destroy ();
  return 0;
}
 

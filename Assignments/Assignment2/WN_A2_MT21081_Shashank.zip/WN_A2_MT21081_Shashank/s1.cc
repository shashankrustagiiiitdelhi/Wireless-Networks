//include the files
#include <fstream>
#include "ns3/core-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/mobility-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/ssid.h"

//groups all ns-3-related declarations in a scope outside the global namespace
using namespace ns3;

//enable and disable console message logging by reference to the name
NS_LOG_COMPONENT_DEFINE ("First Simulation");

//class
class MyApp : public Application{
public:
  //constructor
  MyApp ();
  //destructor
  virtual ~MyApp ();

  void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

private:
  //function declarations
  virtual void StartApplication (void);
  virtual void StopApplication (void);

  void ScheduleTx (void);
  void SendPacket (void);

  //variables
  Ptr<Socket>     m_socket;
  Address         m_peer;
  uint32_t        m_packetSize;
  uint32_t        m_nPackets;
  DataRate        m_dataRate;
  EventId         m_sendEvent;
  bool            m_running;
  uint32_t        m_packetsSent;
};

//initialization of variables
MyApp::MyApp ()
  : m_socket (0),
    m_peer (),
    m_packetSize (0),
    m_nPackets (0),
    m_dataRate (0),
    m_sendEvent (),
    m_running (false),
    m_packetsSent (0)
{
}

//free socket
MyApp::~MyApp ()
{
  m_socket = 0;
}

//setup connections
void
MyApp::Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate)
{
  m_socket = socket;
  m_peer = address;
  m_packetSize = packetSize;
  m_nPackets = nPackets;
  m_dataRate = dataRate;
}

//start applications
void
MyApp::StartApplication (void)
{
  m_running = true;
  m_packetsSent = 0;
  //bind program with socket
  m_socket->Bind ();
  //connection established
  m_socket->Connect (m_peer);
  //start sending data
  SendPacket ();
}

//stop applications
void
MyApp::StopApplication (void)
{
  m_running = false;

  if (m_sendEvent.IsRunning ())
    {
      Simulator::Cancel (m_sendEvent);
    }
  //terminate connection/ release port
  if (m_socket)
    {
      m_socket->Close ();
    }
}

//sending data
void
MyApp::SendPacket (void)
{
  //create packet with specific packetsize
  Ptr<Packet> packet = Create<Packet> (m_packetSize);
  m_socket->Send (packet);
  
  if (++m_packetsSent < m_nPackets)
    {
      ScheduleTx ();
    }
}

//Schedule tasks via simulation
void
MyApp::ScheduleTx (void)
{
  if (m_running)
    {
      Time tNext (Seconds (m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate ())));
      m_sendEvent = Simulator::Schedule (tNext, &MyApp::SendPacket, this);
    }
}

//congestion window change
static void
CwndChange (Ptr<OutputStreamWrapper> stream, uint32_t oldCwnd, uint32_t newCwnd)
{
//   NS_LOG_UNCOND (Simulator::Now ().GetSeconds () << "\t" << newCwnd);
   *stream->GetStream () << Simulator::Now ().GetSeconds () << "\t" << oldCwnd << "\t" << newCwnd << std::endl;
}

// Base Network Topology (ISP->PC1 for generate traffic)
//
//   Wifi 10.1.3.0
//                         AP
// *   *    *    *    *    *
// |    |   |    |    |    |            10.1.1.0
// n5  n4  n3   n2   n1   n0(router) -------------- ISP  
//                         |         point-to-point  
//                      PC1(csma)              
//                         |                
//                      PC2(csma)

//Used topology to generate traffic
//  
//        AP
//        |               10.1.1.0
//    n0(router) ------------------------ ISP (sender)
//        |             point-to-point  
//   PC1(csma)(Receiver)  


int 
main (int argc, char *argv[])
{
  //initialization of variables
  bool verbose = true;
  uint32_t nCsma = 2;
  uint32_t nWifi = 5;
  bool tracing = false;
  double error_rate = 0.000001;
  int simulation_time = 10; //seconds

  CommandLine cmd (__FILE__);
  cmd.AddValue ("nCsma", "Number of \"extra\" CSMA nodes/devices", nCsma);
  cmd.AddValue ("nWifi", "Number of wifi STA devices", nWifi);
  cmd.AddValue ("verbose", "Tell echo applications to log if true", verbose);
  cmd.AddValue ("tracing", "Enable pcap tracing", tracing);

  cmd.Parse (argc,argv);

  // The underlying restriction of 18 is due to the grid position
  // allocator's configuration; the grid layout will exceed the
  // bounding box if more than 18 nodes are provided.
  if (nWifi > 18)
    {
      std::cout << "nWifi should be 18 or less; otherwise grid layout exceeds the bounding box" << std::endl;
      return 1;
    }

  if (verbose)
    {
      LogComponentEnable ("UdpEchoClientApplication", LOG_LEVEL_INFO);
      LogComponentEnable ("UdpEchoServerApplication", LOG_LEVEL_INFO);
    }

  //create the ns-3 pointToPoint Node objects and define the value to 2 nodes
  NodeContainer p2pNodes;
  p2pNodes.Create (2);

  //Physical layer: constructing a point to point link
  PointToPointHelper pointToPoint;
  pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("100Mbps"));
  pointToPoint.SetChannelAttribute ("Delay", StringValue ("2ms"));

  //Create ns-3 device objects and add P2P channel between the nodes
  NetDeviceContainer p2pDevices;
  p2pDevices = pointToPoint.Install (p2pNodes);

  //create csma Node object and define the value as nCsma = 2 (as initialized)
  NodeContainer csmaNodes;
  csmaNodes.Add (p2pNodes.Get (0));
  csmaNodes.Create (nCsma);

  //Physical layer: constructing a csma link
  CsmaHelper csma;
  csma.SetChannelAttribute ("DataRate", StringValue ("100Mbps"));
  csma.SetChannelAttribute ("Delay", TimeValue (NanoSeconds (6560)));

  //Create ns-3 device objects and add csma channel between the nodes
  NetDeviceContainer csmaDevices;
  csmaDevices = csma.Install (csmaNodes);

  //create wifi Station Node object and define the value as nWifi = 5 (as initialized) and make n0 as access point (router)
  NodeContainer wifiStaNodes;
  wifiStaNodes.Create (nWifi);
  NodeContainer wifiApNode = p2pNodes.Get (0);

  //Physical layer setup
  YansWifiChannelHelper channel = YansWifiChannelHelper::Default ();
  YansWifiPhyHelper phy;
  phy.SetChannel (channel.Create ());

  //constructing the wifi link
  WifiHelper wifi;
  wifi.SetRemoteStationManager ("ns3::AarfWifiManager");

  //setup wifi ssid
  WifiMacHelper mac;
  Ssid ssid = Ssid ("ns-3-ssid");
  mac.SetType ("ns3::StaWifiMac",
               "Ssid", SsidValue (ssid),
               "ActiveProbing", BooleanValue (false));

  NetDeviceContainer staDevices;
  staDevices = wifi.Install (phy, mac, wifiStaNodes);

  mac.SetType ("ns3::ApWifiMac",
               "Ssid", SsidValue (ssid));

  NetDeviceContainer apDevices;
  apDevices = wifi.Install (phy, mac, wifiApNode);

  //allows wireless device to move around within a confined area which perfectly resembles a typical wireless device mobility
  MobilityHelper mobility;

  mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
                                 "MinX", DoubleValue (0.0),
                                 "MinY", DoubleValue (0.0),
                                 "DeltaX", DoubleValue (5.0),
                                 "DeltaY", DoubleValue (10.0),
                                 "GridWidth", UintegerValue (3),
                                 "LayoutType", StringValue ("RowFirst"));

  mobility.SetMobilityModel ("ns3::RandomWalk2dMobilityModel",
                             "Bounds", RectangleValue (Rectangle (-50, 50, -50, 50)));
  mobility.Install (wifiStaNodes);

  mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
  mobility.Install (wifiApNode);

  //to check what the PointToPointHelper/CsmaHelper/WifiHelper is to point-to-point/csma/wifi net devices
  InternetStackHelper stack;
  stack.Install (csmaNodes);
  stack.Install (p2pNodes.Get(1));
  //stack.Install (wifiApNode);
  stack.Install (wifiStaNodes);

  Ipv4AddressHelper address;
  //associate the devices with IP addresses
  address.SetBase ("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer p2pInterfaces;
  p2pInterfaces = address.Assign (p2pDevices);

  address.SetBase ("10.1.2.0", "255.255.255.0");
  Ipv4InterfaceContainer csmaInterfaces;
  csmaInterfaces = address.Assign (csmaDevices);

  address.SetBase ("10.1.3.0", "255.255.255.0");
  address.Assign (staDevices);
  address.Assign (apDevices);
  
  //Error model
  Ptr<RateErrorModel> em = CreateObject<RateErrorModel> ();
  em->SetAttribute ("ErrorRate", DoubleValue (error_rate));
  p2pDevices.Get (1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));
  
  //Receiver(PC1) - node 0
  uint16_t sinkPort = 8080;
  Address sinkAddress (InetSocketAddress (csmaInterfaces.GetAddress (1), sinkPort));
  PacketSinkHelper packetSinkHelper ("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), sinkPort));
  ApplicationContainer sinkApps = packetSinkHelper.Install (csmaNodes.Get (1));
  sinkApps.Start (Seconds (0.));
  sinkApps.Stop (Seconds (simulation_time));

  //Sender(ISP)
  Ptr<Socket> ns3TcpSocket = Socket::CreateSocket (p2pNodes.Get (1), TcpSocketFactory::GetTypeId ());

  Ptr<MyApp> app = CreateObject<MyApp> ();
  app->Setup (ns3TcpSocket, sinkAddress, 1460, 1000000, DataRate ("100Mbps"));
  p2pNodes.Get (1)->AddApplication (app);
  app->SetStartTime (Seconds (1.));
  app->SetStopTime (Seconds (simulation_time));

  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

  //trace cwnd
  AsciiTraceHelper asciiTraceHelper;
  Ptr<OutputStreamWrapper> stream = asciiTraceHelper.CreateFileStream ("s1.cwnd");
  ns3TcpSocket->TraceConnectWithoutContext ("CongestionWindow", MakeBoundCallback (&CwndChange, stream));

  //detailed trace of queue enq/deq packet tx/rx
  AsciiTraceHelper ascii;
  pointToPoint.EnableAsciiAll (ascii.CreateFileStream ("s1.tr"));
  pointToPoint.EnablePcapAll ("s1");

  Simulator::Stop (Seconds (simulation_time));  
  //run the simulation using the global function Simulator::Run
  Simulator::Run ();
  //All that remains is to clean up
  Simulator::Destroy ();
  return 0;
}
 
